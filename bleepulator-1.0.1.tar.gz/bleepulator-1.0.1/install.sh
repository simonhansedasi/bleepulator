#!/bin/bash
set -e

BLEEPULATOR_DIR="$HOME/.local/share/sounds/bleepulator"
YARU_DIR="$HOME/.local/share/sounds/Yaru"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "=== Bleepulator Installer ==="
echo ""

echo "[1/4] Installing sounds..."
mkdir -p "$BLEEPULATOR_DIR/stereo"
cp "$SCRIPT_DIR/stereo/"*.oga "$BLEEPULATOR_DIR/stereo/"
cp "$SCRIPT_DIR/index.theme"  "$BLEEPULATOR_DIR/index.theme"

echo "[2/4] Activating theme..."
if command -v gsettings &>/dev/null; then
    gsettings set org.gnome.desktop.sound theme-name 'bleepulator'
    gsettings set org.gnome.desktop.sound event-sounds true
else
    echo "  gsettings not found — run this manually:"
    echo "  gsettings set org.gnome.desktop.sound theme-name 'bleepulator'"
fi

echo "[3/4] Installing apt-resilience layer..."
mkdir -p "$YARU_DIR/stereo"
cat > "$YARU_DIR/index.theme" << 'EOF'
[Sound Theme]
Name=Yaru
Directories=stereo

[stereo]
OutputProfile=stereo
EOF
for oga in "$BLEEPULATOR_DIR/stereo/"*.oga; do
    ln -sf "$oga" "$YARU_DIR/stereo/$(basename "$oga")"
done

echo "[4/4] Patching login sound..."
mkdir -p "$HOME/.config/autostart"
cat > "$HOME/.config/autostart/libcanberra-login-sound.desktop" << EOF
[Desktop Entry]
Type=Application
Name=GNOME Login Sound
Exec=/usr/bin/canberra-gtk-play --file="$BLEEPULATOR_DIR/stereo/desktop-login.oga" --description="GNOME Login"
OnlyShowIn=GNOME;Unity;
AutostartCondition=GSettings org.gnome.desktop.sound event-sounds
X-GNOME-Autostart-Phase=Application
X-GNOME-Provides=login-sound
X-GNOME-Autostart-enabled=true
NoDisplay=true
EOF

echo ""
echo "Done. Log out and back in for the login sound to take effect."
echo ""
echo "To uninstall:"
echo "  rm -rf ~/.local/share/sounds/bleepulator ~/.local/share/sounds/Yaru"
echo "  rm -f  ~/.config/autostart/libcanberra-login-sound.desktop"
echo "  gsettings reset org.gnome.desktop.sound theme-name"
